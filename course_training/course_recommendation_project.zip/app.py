
import streamlit as st
import pandas as pd
import joblib


# Load model
data = joblib.load("course_recommendation_model.pkl")

model = data["model"]
preprocessor = data["preprocessor"]
label_encoders = data["label_encoders"]
target_columns = data["target_columns"]
fields = data["fields"]


# Page settings
st.set_page_config(
    page_title="Course Recommendation System",
    page_icon="🎓",
    layout="wide"
)


# Title
st.title("🎓 Course Recommendation System")

st.write(
    "Enter your field, hobbies, grades and aptitude scores "
    "to predict your Top 5 suitable courses."
)


# -------------------------
# FIELD
# -------------------------

st.subheader("🎓 Select Your Field")

field = st.selectbox(
    "Field",
    fields
)


# -------------------------
# HOBBIES
# -------------------------

st.subheader("🎯 Hobbies")

hobby_columns = [
    "hobby_coding",
    "hobby_gaming",
    "hobby_reading",
    "hobby_writing",
    "hobby_music",
    "hobby_drawing_art",
    "hobby_sports",
    "hobby_cooking",
    "hobby_photography",
    "hobby_travel",
    "hobby_science_experiments",
    "hobby_volunteering",
    "hobby_debating",
    "hobby_robotics",
    "hobby_fashion",
    "hobby_business_trading"
]

student = {
    "field_filter": field
}

cols = st.columns(4)

for i, hobby in enumerate(hobby_columns):

    name = hobby.replace("hobby_", "").replace("_", " ").title()

    with cols[i % 4]:
        selected = st.checkbox(name)

    student[hobby] = 1 if selected else 0


# -------------------------
# GRADES
# -------------------------

st.subheader("📚 Grades")

grade_columns = [
    "grade_math",
    "grade_science",
    "grade_lang",
    "grade_social",
    "grade_cs"
]

grade_names = {
    "grade_math": "Math",
    "grade_science": "Science",
    "grade_lang": "Language",
    "grade_social": "Social",
    "grade_cs": "Computer Science"
}

cols = st.columns(5)

for i, grade in enumerate(grade_columns):

    with cols[i]:
        student[grade] = st.number_input(
            grade_names[grade],
            min_value=0.0,
            max_value=100.0,
            value=50.0
        )


# -------------------------
# SCORES
# -------------------------

st.subheader("🧠 Aptitude Scores")

score_columns = [
    "score_analytical",
    "score_numeric",
    "score_verbal",
    "score_creative",
    "score_social"
]

score_names = {
    "score_analytical": "Analytical",
    "score_numeric": "Numeric",
    "score_verbal": "Verbal",
    "score_creative": "Creative",
    "score_social": "Social"
}

cols = st.columns(5)

for i, score in enumerate(score_columns):

    with cols[i]:
        student[score] = st.number_input(
            score_names[score],
            min_value=0.0,
            max_value=100.0,
            value=50.0
        )


# -------------------------
# PREDICTION
# -------------------------

if st.button("🔮 Predict Top 5 Courses", use_container_width=True):

    student_df = pd.DataFrame([student])

    processed = preprocessor.transform(student_df)

    prediction = model.predict(processed)

    st.subheader("🏆 Recommended Top 5 Courses")

    for i, col in enumerate(target_columns):

        course = label_encoders[col].inverse_transform(
            prediction[:, i]
        )[0]

        if i == 0:
            st.success(f"🥇 {course}")

        elif i == 1:
            st.info(f"🥈 {course}")

        elif i == 2:
            st.warning(f"🥉 {course}")

        else:
            st.write(f"**{i + 1}. {course}**")
